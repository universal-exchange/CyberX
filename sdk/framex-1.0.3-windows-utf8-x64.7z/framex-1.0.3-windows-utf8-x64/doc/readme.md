# FrameX
V1.0.3 Build 20220117

© 2017-2022 Xu Rendong. All Rights Reserved.

### Project Summary
Basic Development Framework.

### Contact Information
QQ: 277195007, WeChat: xrd_ustc, E-mail: xrd@ustc.edu
