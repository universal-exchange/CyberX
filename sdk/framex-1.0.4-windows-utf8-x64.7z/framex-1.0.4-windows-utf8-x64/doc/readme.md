# FrameX
V1.0.4 Build 20240731

© 2017-2024 Xu Rendong. All Rights Reserved.

### Project Summary
Basic Development Framework.

### Contact Information
WeChat：xrd_ustc，~~QQ：277195007~~，~~E-mail：xrd@ustc.edu~~
